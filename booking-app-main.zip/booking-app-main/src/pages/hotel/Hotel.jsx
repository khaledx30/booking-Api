export default function Hotel() {
  return <div>Hotel</div>;
}
