import Navbar from "./../../components/Navbar/Navbar";
import Header from "./../../components/header/Header";
export default function List() {
  return (
    <div>
      <Navbar></Navbar>
      <Header></Header>
    </div>
  );
}
